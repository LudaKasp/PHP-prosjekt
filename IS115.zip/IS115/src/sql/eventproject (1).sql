-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2022 at 09:38 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE eventproject;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `eventID` int(11) NOT NULL,
  `eventnavn` varchar(255) NOT NULL,
  `eventtid` datetime NOT NULL,
  `eventsted` varchar(255) NOT NULL,
  `beskrivelse` varchar(1000) NOT NULL,
  `katnavn` varchar(255) NOT NULL,
  `epost` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`eventID`, `eventnavn`, `eventtid`, `eventsted`, `beskrivelse`, `katnavn`, `epost`) VALUES
(28, 'Konsert på Østsia', '2022-12-29 21:22:00', 'Østsia Uia', ' 4654654', 'Konsert', 'kapny2009@hotmail.no'),
(30, 'Østsiden konsert', '2022-12-27 00:00:00', 'Østsiden', ' dsadasda', 'Konsert', 'kapny2009@hotmail.no'),
(33, 'Quiz på Harveys', '2022-12-29 21:27:00', 'Harveys', ' Tobias hoster quiz!', 'Quiz', 'tobias@skole.no'),
(34, 'Julekonsert på Østsia', '2022-12-22 21:30:00', 'Østsia UIa', ' Tobias synger julen inn på Østsia!', 'Konsert', 'tobias@skole.no'),
(37, 'Julebad i Baneheia', '2022-12-23 10:30:00', 'Baneheia', 'Ring julen inn med et isbad i baneheia!', 'Annet', 'bruker@hotmail.no');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uploaded_on` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `eventID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `fname`, `uploaded_on`, `status`, `eventID`) VALUES
(7, 'ostsia.jpg', '2022-12-06 14:14:42', '1', 28),
(10, 'harveys.png', '2022-12-06 21:27:51', '1', 33),
(11, 'ostsia2.jpg', '2022-12-06 21:29:04', '1', 34),
(14, 'baneheia.jpg', '2022-12-06 21:35:05', '1', 37);

-- --------------------------------------------------------

--
-- Table structure for table `kategorier`
--

CREATE TABLE `kategorier` (
  `katID` int(11) NOT NULL,
  `katnavn` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategorier`
--

INSERT INTO `kategorier` (`katID`, `katnavn`) VALUES
(3, 'Annet'),
(2, 'Konsert'),
(1, 'Quiz');

-- --------------------------------------------------------

--
-- Table structure for table `pamelding`
--

CREATE TABLE `pamelding` (
  `pID` int(11) NOT NULL,
  `eventID` int(11) NOT NULL,
  `epost` varchar(255) NOT NULL,
  `pDato` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pamelding`
--

INSERT INTO `pamelding` (`pID`, `eventID`, `epost`, `pDato`) VALUES
(31, 28, 'bruker@hotmail.no', '2022-12-06 00:00:00'),
(32, 30, 'kapny2009@hotmail.no', '2022-12-06 19:55:10'),
(34, 33, 'tobias@skole.no', '2022-12-06 21:28:03'),
(35, 28, 'tobias@skole.no', '2022-12-06 21:28:07'),
(36, 30, 'tobias@skole.no', '2022-12-06 21:28:10'),
(37, 34, 'tobias@skole.no', '2022-12-06 21:29:08'),
(38, 33, 'bruker@hotmail.no', '2022-12-06 21:30:16'),
(39, 34, 'bruker@hotmail.no', '2022-12-06 21:30:19'),
(40, 37, 'bruker@hotmail.no', '2022-12-06 21:35:14'),
(41, 28, 'kapny2009@hotmail.no', '2022-12-06 21:36:43'),
(42, 33, 'kapny2009@hotmail.no', '2022-12-06 21:36:49'),
(43, 34, 'kapny2009@hotmail.no', '2022-12-06 21:36:52'),
(44, 37, 'kapny2009@hotmail.no', '2022-12-06 21:36:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `fnavn` varchar(255) NOT NULL,
  `enavn` varchar(255) NOT NULL,
  `tlf` varchar(8) NOT NULL,
  `epost` varchar(255) NOT NULL,
  `regdato` datetime NOT NULL,
  `passord` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `fnavn`, `enavn`, `tlf`, `epost`, `regdato`, `passord`) VALUES
(1, 'Kasper', 'Skjæveland', '97719300', 'kapny2009@hotmail.no', '2022-11-28 00:00:00', '$2y$10$UlUN3F0OgMO/GAqnTZS9Iug8TJWaLTLV2O6QAQYtbd6Vy5qEYPesm'),
(2, 'Nancy', 'Idland', '93013694', 'nancyidland@live.no', '2022-11-28 00:00:00', '$2y$10$w5ZYrD/QDnFKvFAuOuXJvOsEZh99GYINIgQ0Kf.MPemQ1O6D5QU8i'),
(8, 'Kieran', 'Skjæveland', '93012500', 'kieran1412@hotmail.com', '2022-11-28 00:00:00', '$2y$10$RZVte1israpRTOFGIB0nOO.pZcHvwguAtJFySK5qaAGBULg7pJyIm'),
(11, 'Egget', 'Skjegget', '97756200', 'eggetmedskjegget@corner.no', '2022-12-01 00:00:00', '$2y$10$VwqvkwIYLD2g732vUshpJ.Zb9KoKonSVLkvuAIT3x/ZlR9fROp022'),
(12, 'Bruker', 'Bruker', '12378945', 'bruker@hotmail.no', '2022-12-06 00:00:00', '$2y$10$wFoCkfwTvZIPabMng3Pex.pdsd1qrawFWxmE8kxBvJ3TpHhixwmtW'),
(13, 'Tobias', 'Ekholt', '95175312', 'tobias@skole.no', '2022-12-06 21:26:06', '$2y$10$Tz7qz88G/1Bug6N12.qmAe6Bgl27qviPoXjMQ3oq3g8Hn2gwbWkk6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`eventID`),
  ADD KEY `katnavn` (`katnavn`),
  ADD KEY `epost` (`epost`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eventID` (`eventID`);

--
-- Indexes for table `kategorier`
--
ALTER TABLE `kategorier`
  ADD PRIMARY KEY (`katID`),
  ADD UNIQUE KEY `katnavn` (`katnavn`);

--
-- Indexes for table `pamelding`
--
ALTER TABLE `pamelding`
  ADD PRIMARY KEY (`pID`),
  ADD KEY `epost` (`epost`),
  ADD KEY `eventID` (`eventID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `epost` (`epost`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `eventID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `kategorier`
--
ALTER TABLE `kategorier`
  MODIFY `katID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pamelding`
--
ALTER TABLE `pamelding`
  MODIFY `pID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`katnavn`) REFERENCES `kategorier` (`katnavn`),
  ADD CONSTRAINT `events_ibfk_2` FOREIGN KEY (`epost`) REFERENCES `users` (`epost`);

--
-- Constraints for table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_ibfk_1` FOREIGN KEY (`eventID`) REFERENCES `events` (`eventID`);

--
-- Constraints for table `pamelding`
--
ALTER TABLE `pamelding`
  ADD CONSTRAINT `pamelding_ibfk_1` FOREIGN KEY (`epost`) REFERENCES `users` (`epost`),
  ADD CONSTRAINT `pamelding_ibfk_2` FOREIGN KEY (`eventID`) REFERENCES `events` (`eventID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
