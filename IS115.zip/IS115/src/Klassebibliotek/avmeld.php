<?php

include('../includes/db.inc.php');

//får id fra hyperlink i pameldte.php
$id = $_GET['id'];

//lager query for å komme til oversikt over påmeldte
$sql = "SELECT eventID FROM pamelding 
        WHERE pID = :id";

//lager prepared statement
$q = $pdo->prepare($sql);
//binder parameter til variabel
$q->bindParam(':id', $id, PDO::PARAM_INT); 

//kjører queryen mot databasen
try {
    $q->execute();
} catch (PDOException $e) {
    //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
}

//henter resultatet av queryen til arrayet result
$result = $q->fetch(PDO::FETCH_OBJ);

//spørring som sletter påmeldt basert på pID
$sql = "DELETE FROM pamelding 
        WHERE pID = :id";

//prepared statement
$q = $pdo->prepare($sql);
//binder parameter
$q->bindParam(':id', $id, PDO::PARAM_INT); 

////kjører queryen mot databasen
try {
    $q->execute();
} catch (PDOException $e) {
    echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
}

header("Location: ./pameldte.php?id=$result->eventID");
echo ""
?>