<?php
include('../includes/Header.inc.php');
include('../includes/login.inc.php');
require_once('../includes/db.inc.php');


//kode skjer kun om logg inn knappen er trykket
if(isset($_REQUEST['logginn']))
{
    //spørring til database for å hente ut passord
    $sql = "SELECT passord
    FROM users
    WHERE epost = :epost";

    //lager en prepared statement for sql koden
    $q = $pdo->prepare($sql);
    $q->bindParam(':epost', $epost, PDO::PARAM_STR);

    //henter input fra bruker inn i en variabel
    $epost = $_REQUEST['epost'];

    //prøver å koble til databasen og kjøre queryen
    try {
        $q->execute();
        $result = $q->fetch(PDO::FETCH_OBJ);
    } catch (PDOException $e) {
        //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
    }
    

    //sjekker at passordet stemmer med å dekryptere passordet
    if($result !== false && password_verify(strip_tags($_REQUEST['passord']), $result->passord))
    {
        //starter en session for brukeren om passordet stemmer
        session_start();
        $_SESSION['bruker']['navn'] = $epost;
        $_SESSION['bruker']['innlogget'] = true;
        header("Location: ./index.php"); 
    exit();
  }
  else 
  {
    echo "<center><b>Innlogging feilet.<br> Vennligst prøv igjen.</b><center>";
  }
}

include('../includes/Footer.inc.php');
