<?php
include('../includes/Header.inc.php');
include('../includes/registrering.inc.php');
require_once('../includes/db.inc.php');

//kode som kjøres om registreringsknappen blir trykket
if (isset($_REQUEST['registerbtn'])) {
  
  $passord1 = $_REQUEST['passord'];
  $passord2 = $_REQUEST['psw-repeat'];
  $suksess = true;

  //sjekker om passordene er like
  if($passord1 != $passord2)
  {
    feilmelding();
    $suksess = false;
  }
  
  //sql kode for å sette inn i databasen
  if($suksess == true)
{
  $sql = "INSERT INTO users 
        (fnavn, enavn, tlf, epost, regdato, passord) 
        VALUES 
        (:fnavn, :enavn, :tlf, :epost, :regdato, :passord)";

  //lager en prepared statement
  $q = $pdo->prepare($sql);

  $q->bindParam(':fnavn', $fnavn, PDO::PARAM_STR);
  $q->bindParam(':enavn', $enavn, PDO::PARAM_STR);
  $q->bindParam(':tlf', $tlf, PDO::PARAM_STR);
  $q->bindParam(':epost', $epost, PDO::PARAM_STR);
  $q->bindParam(':regdato', $regdato, PDO::PARAM_STR);
  $q->bindParam(':passord', $passord, PDO::PARAM_STR);

  //legger input inn i variabler
  $fnavn = $_REQUEST['fnavn'];
  $enavn = $_REQUEST['enavn'];
  $tlf = $_REQUEST['tlf'];
  $epost = $_REQUEST['epost'];
  $regdato = date('Y-m-d H:i:s');
  $passord = password_hash($_REQUEST['passord'], PASSWORD_DEFAULT);

  //prøver å koble til databasen
  try {
    $q->execute();
  } catch (PDOException $e) {
    echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
  }
  //$q->debugDumpParams();

  //gir tilbakemelding om brukeren har blitt opprettet eller ikke
  if ($pdo->lastInsertId() > 0) {
    echo "<center><b>Brukeren har blitt opprettet.</b></center>";
  } else {
    echo "<center><b>Det skjedde en feil. Prøv igjen.</b></center>";
  }
}
}


include('../includes/Footer.inc.php');
