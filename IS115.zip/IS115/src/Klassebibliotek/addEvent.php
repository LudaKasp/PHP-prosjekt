<?php
//avgjør hvilken header basert på om du er innlogget eller ikke
session_start();
if (isset($_SESSION['bruker']['innlogget']) !== true) {
  include('../includes/Header.inc.php');
} else {
  include('../includes/Header.loggedin.inc.php');
}
include('../includes/addEvent.inc.php');
require_once('../includes/db.inc.php');

//kjøres om add event knappen blir trykket
if (isset($_REQUEST['addEvent'])) {
  //sql kode for å sette inn i databasen
  $sql = "INSERT INTO events 
        (eventnavn, eventtid, eventsted, beskrivelse, katnavn, epost) 
        VALUES 
        (:eventnavn, :eventtid, :eventsted, :beskrivelse, :katnavn, :epost)";

  //lager en prepared statement
  $q = $pdo->prepare($sql);

  //binder variabler til parameter
  $q->bindParam(':eventnavn', $eventnavn, PDO::PARAM_STR);
  $q->bindParam(':eventtid', $eventtid, PDO::PARAM_STR);
  $q->bindParam(':eventsted', $eventsted, PDO::PARAM_STR);
  $q->bindParam(':beskrivelse', $beskrivelse, PDO::PARAM_STR);
  $q->bindParam(':katnavn', $katnavn, PDO::PARAM_STR);
  $q->bindParam(':epost', $epost, PDO::PARAM_STR);

  //legger input inn i variabler
  $eventnavn = $_REQUEST['eventnavn'];
  $eventtid = $_REQUEST['eventtid'];
  $eventsted = $_REQUEST['eventsted'];
  $beskrivelse = $_REQUEST['beskrivelse'];
  $katnavn = $_REQUEST['katnavn'];
  $epost = $_SESSION['bruker']['navn'];

  //prøver å koble til databasen og kjøre queryen
  try {
    $q->execute();
  } catch (PDOException $e) {
    //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
  }

  //sjekker om id er lagt til i database og gir tilbakemelding
  if ($pdo->lastInsertId() > 0) {
    echo "<center><b>Eventet har blitt opprettet.</b></center>";
  } else {
    echo "<center><b>Noe gikk galt.</b></center>";
  }

  $eventid = $pdo->lastInsertId();

  $targetDir = "../img/";
  $filename = basename($_FILES["file"]["name"]);
  $targetFilePath = $targetDir . $filename;
  $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

  if(!empty($_FILES["file"]["name"]))
  {
    //legger godkjente filtyper inn i variabel
    $allowTypes = array('jpg','png','jpeg','gif','pdf');
    if(in_array($fileType, $allowTypes)){
        // Upload file to server
        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath))
        {
          //sql kode for å sette inn i databasen
          $sql = "INSERT INTO images
          (fname, uploaded_on, eventID)
          VALUES
          (:fname, :uploaded_on, :eventID)";
          //lager en prepared statement
          $q = $pdo->prepare($sql);
          //binder variabler til parameter
          $q->bindParam(':fname', $filename, PDO::PARAM_STR);
          $q->bindParam(':uploaded_on', $uploaded_on, PDO::PARAM_STR);
          $q->bindParam(':eventID', $eventid, PDO::PARAM_STR);

          $uploaded_on = date('Y-m-d H:i:s');

          //prøver å koble til databasen og kjøre queryen
          try {
            $q->execute();
        } catch (PDOException $e) {
            //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
        }
        

        }
    }
  }
}
include('../includes/Footer.inc.php');
?>
