<?php

include('../includes/db.inc.php');

//får eventID fra hyperlink i myProfile
$id = $_GET['id'];
//query som sletter alle påmeldinger knyttet til eventet
$sql = "DELETE FROM pamelding 
        WHERE eventID = :id";
//prepared statement
$q = $pdo->prepare($sql);
//binder parameter
$q->bindParam(':id', $id, PDO::PARAM_INT); 
//kjører queryen
try {
    $q->execute();
} catch (PDOException $e) {
    //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
}

//sletter alle bilder knyttet til eventet
$sql = "DELETE FROM images 
        WHERE eventID = :id";

$q = $pdo->prepare($sql);
$q->bindParam(':id', $id, PDO::PARAM_INT); 

try {
    $q->execute();
} catch (PDOException $e) {
    //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
}

//sletter eventet
$sql = "DELETE FROM events 
        WHERE eventID = :id";

$q = $pdo->prepare($sql);
$q->bindParam(':id', $id, PDO::PARAM_INT); 

try {
    $q->execute();
} catch (PDOException $e) {
    //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
}

header("Location: ./myProfile.php"); 


?>