<?php

require_once('../includes/db.inc.php');
//avgjør hvilken header basert på om du er innlogget eller ikke
session_start();
    if(isset($_SESSION['bruker']['innlogget']) !== true){
        include('../includes/Header.inc.php');
    } else{
        include('../includes/Header.loggedin.inc.php');

    }

?>

<center><caption><h1>Kommende events:</h1></caption>
<table border="2">
<th>Navn</th>
<th>Kategori</th>
<th>Tidspunkt</th>
<th>Sted</th>
<th></th></center>
<?php
//query som kobler til database, og velger alle radene fra events
$events = mysqli_query($db,"select * from events"); // fetch data from database
//hvis det er data i events så printes det ut i tabell
while($data = mysqli_fetch_array($events))
{
?>
  <tr>
    <td><?php echo $data['eventnavn']; ?></td>
    <td><?php echo date("d-m-Y H:i", strtotime($data['eventtid'])); ?></td>
    <td><?php echo $data['eventsted']; ?></td>
    <td><?php echo $data['katnavn']; ?></td>     
    <td><a href="eventInfo.php?id=<?php echo $data['eventID']; ?>">Les mer</a></td>
  </tr>	
<?php
}

echo "</table>". "<br>";

include('../includes/Footer.inc.php');
?>