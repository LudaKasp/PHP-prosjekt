<?php 
session_start();
//avgjør hvilken header basert på om du er innlogget eller ikke
if(isset($_SESSION['bruker']['innlogget']) !== true){
    include('../includes/Header.inc.php');
} else{
    include('../includes/Header.loggedin.inc.php');

}
include("../includes/db.inc.php");
?>

<center><form action="pameldte.php">
<br><br><button type="submit" name="tilbake">Tilbake</button><br><br>
</form>
<?php
if(isset($_REQUEST['tilbake']))
{
    header("Location: ./myProfile.php");
}
?>

<h2>Påmeldte for ditt event</h2>

<table border="2">
  <tr>
    <td><b>Påmeldte</b></td>
  </tr>

  <?php
  //får eventID fra hyperlink i myProfile.php
  $id = $_GET['id'];
  $sql = "SELECT epost, pID FROM pamelding WHERE eventID = :eventID";

  //lager en prepared statement
  $q = $pdo->prepare($sql);
  //binder parameter
  $q->bindParam(':eventID', $id, PDO::PARAM_STR);
  try {
    $q->execute();
  } catch (PDOException $e) {
    //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
  }
  
  //henter resulat inn i arrayet pameldinger
  $pameldinger = $q->fetchAll(PDO::FETCH_OBJ);

  //hvis spørringen resulterte i data så lister den opp innholdet
  if($q->rowCount() > 0) {
    foreach($pameldinger as $pamelding) {
  ?>
    <tr>
      <td><?php echo $pamelding->epost; ?></td>
      <!-- hyperlink til avmeld.php med id=pID -->
      <td><a href="avmeld.php?id=<?php echo $pamelding->pID; ?>">Slett</a></td>
    </tr>
  <?php
  }
}
  ?>
</table></center>
<br><br>

<?php 
include("../includes/Footer.inc.php")
?>

