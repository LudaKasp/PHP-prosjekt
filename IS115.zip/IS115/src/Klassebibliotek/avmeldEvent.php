<?php
include('../includes/db.inc.php');

//henter pID fra myProfile
$id = $_GET['id'];

//spørring som sletter påmelding
$sql = "DELETE FROM pamelding 
        WHERE pID = :id";

//prepared statement
$q = $pdo->prepare($sql);
//binder parameter
$q->bindParam(':id', $id, PDO::PARAM_INT); 

//kjører queryen
try {
    $q->execute();
} catch (PDOException $e) {
    //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
}
//sendes tilbake til myProfile
header("Location: ./myProfile.php"); 
?>