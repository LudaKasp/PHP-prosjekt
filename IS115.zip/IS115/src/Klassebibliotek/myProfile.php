<?php
include('../includes/db.inc.php');
//avgjør hvilken header basert på om du er innlogget eller ikke
session_start();
if (isset($_SESSION['bruker']['innlogget']) !== true) {
  include('../includes/Header.inc.php');
} else {
  include('../includes/Header.loggedin.inc.php');
}
?>

<center><h2>Mine events</h2>

<table border="2">
  <tr>
    <td><b>Eventnavn</b></td>
    <td><b>Tidspunkt</b></td>
    <td><b>Sted</b></td>
    <td><b>Kategori</b></td>
    <td><b>Antall påmeldte</b></td>
    <td><b>Se påmeldte</b></td>
    <td><b>Endre</b></td>
    <td><b>Slett</b></td>
  </tr>

  <?php
  //henter epost til bruker inn i en variabel
  $epost = $_SESSION['bruker']['navn'];
  //query for å hente data fra events hvor epost er lik brukerens epost
  $sql = "SELECT * FROM events WHERE epost = :epost";

  //lager en prepared statement
  $q = $pdo->prepare($sql);
  //binder parameter
  $q->bindParam(':epost', $epost, PDO::PARAM_STR);
  //kjører query
  try {
    $q->execute();
  } catch (PDOException $e) {
    //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
  }
  //henter resultat av query inn i array events
  $events = $q->fetchAll(PDO::FETCH_OBJ);
  //hvis spørringen resulterte i data
  if($q->rowCount() > 0) {
    //printes events ut
    foreach($events as $event) {
  ?>
    <tr>
      <td><?php echo $event->eventnavn; ?></td>
      <td><?php echo date("d-m-Y H:i", strtotime($event->eventtid)); ?></td>
      <td><?php echo $event->eventsted; ?></td>
      <td><?php echo $event->katnavn; ?></td>
      <?php 
      //teller antall påmeldte ved hjelp av rowcount
      $sql = "SELECT pID FROM pamelding WHERE eventID = :eventID";
      $query = $pdo->prepare($sql);
      $query->bindParam(':eventID', $event->eventID, PDO::PARAM_STR);
      try {
        $query->execute();
      } catch (PDOException $e) {
        //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
      }
      //printer ut antall rows returnert av spørringen
      ?>
      <td><?php echo $query->rowcount(); ?></td>
      <!-- hyperlink til pameldte.php med id=eventID -->
      <td><a href="pameldte.php?id=<?php echo $event->eventID; ?>">Se påmeldte</a></td>
      <!-- hyperlink til manageEvent.php med id=eventID -->
      <td><a href="manageEvent.php?id=<?php echo $event->eventID; ?>">Endre</a></td>
      <!-- hyperlink til deleteEvent.php med id=eventID -->
      <td><a href="deleteEvent.php?id=<?php echo $event->eventID; ?>">Slett</a></td>
    </tr>
  <?php
  }
}
  ?>
</table>
<br>

<h2>Mine påmeldinger</h2>

<table border="2">
  <tr>
    <td><b>Eventnavn</b></td>
    <td><b>Tidspunkt</b></td>
    <td><b>Sted</b></td>
    <td><b>Kategori</b></td>
    <td><b>Påmeldingstidspunkt</b></td>
    <td><b>Se event</b></td>
    <td><b>Avmeld</b></td>
  </tr>

  <?php
  //spørring som henter eventinfo, pDato og pID fra tabellene pameldinger og events
  $sql2 = "SELECT E.eventID, E.eventnavn, E.eventtid, E.eventsted, E.katnavn, P.pDato, P.pID 
  FROM pamelding P
  INNER JOIN events E on P.eventID = E.eventID
  WHERE P.epost = :epost";

  //lager en prepared statement
  $q = $pdo->prepare($sql2);
  //binder parameter
  $q->bindParam(':epost', $epost, PDO::PARAM_STR);
  //kjører queryen
  try {
    $q->execute();
  } catch (PDOException $e) {
    //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
  }
  //henter resultat inn i arrayet pameldinger
  $pameldinger = $q->fetchAll(PDO::FETCH_OBJ);
  //hvis spørringen resulterte i data så lister den opp infoen
  if($q->rowCount() > 0) {
    foreach($pameldinger as $pamelding) {
  ?>
    <tr>
      <td><?php echo $pamelding->eventnavn; ?></td>
      <td><?php echo date("d-m-Y H:i", strtotime($pamelding->eventtid)); ?></td>
      <td><?php echo $pamelding->eventsted; ?></td>
      <td><?php echo $pamelding->katnavn; ?></td>
      <td><?php echo date("d-m-Y H:i", strtotime($pamelding->pDato)); ?></td>
      <td><a href="eventInfo.php?id=<?php echo $pamelding->eventID; ?>">Se event</a></td>
      <td><a href="avmeldEvent.php?id=<?php echo $pamelding->pID; ?>">Avmeld</a></td>
    </tr>
  <?php
  }
}
  ?>
</table></center>
<br><br>

  <!-- Logg ut knappen -->
  <center><form action="" method="post">
    <input type="submit" name="logout" value="Logg ut">

  </form></center>

  <?php

  // Når logg ut trykkes på fjernes session og du blir sendt til hjemsiden
  if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
  }

  include('../includes/Footer.inc.php');
  ?>