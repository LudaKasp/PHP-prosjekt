<?php
include('../includes/db.inc.php');
//avgjør hvilken header basert på om du er innlogget eller ikke
session_start();
    if(isset($_SESSION['bruker']['innlogget']) !== true){
        include('../includes/Header.inc.php');
    } else{
        include('../includes/Header.loggedin.inc.php');

    }

//spørring til database for å hente ut events
$sql = "SELECT eventnavn, katnavn, eventtid, eventsted
    FROM events";
//prepared statement
$q = $pdo->prepare($sql);
//kjører queryen
try {
    $q->execute();
} catch (PDOException $e) {
    //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
}

?>

<?php
//henter eventID
$id = $_GET['id'];

//velger alt fra events hvor eventID tilsvarer eventet som blir trykket på
$events = mysqli_query($db,"select * from events where eventID = $id");

//dersom eventet har noe som tilsvarer eventID, så hentes dataen
while($data = mysqli_fetch_array($events))
{
?>
<!-- plasserer dataen som er hente fra queryen i html tabell -->
  <body>
    <main>
        <center><h2><?php echo $data["eventnavn"]?></h2><br>
        <h4>Beskrivelse: </h4>
        <?php echo $data["beskrivelse"]?><br>
        <h4>Sted: </h4>
        <?php echo $data["eventsted"]?><br>
        <h4>Dato: </h4>
        <?php echo date("d/m/Y H:i", strtotime($data["eventtid"]))?>
        <br>
        <?php 
        //velger alt fra images hvor eventID tilsvarer eventet som blir trykket på
        $query = $db->query("SELECT * FROM images WHERE eventID = $id");
        //så lenge det finnes et bilde så printes bildet ut
        if($query->num_rows > 0)
        {
          while($row = $query->fetch_assoc())
          {
            $imageURL = '../img/'.$row["fname"]; ?>
            <img src="<?php echo $imageURL; ?>" alt="" /> <br><br> <?php
          }
        }
        ?>
    </main>
  </body>
  
<?php
}

?>

<form action="" method="post">
    <center><input type="submit" name="pameld" value="Meld på"></center>
</form>

<?php
// hvis knappen fra formen over trykkes
if (isset($_POST['pameld'])) {
// hvis en session er aktiv
  if(($_SESSION['bruker']['innlogget']) == true) {
//sjekker om bruker allerede er påmeldt
    $sql2 = "SELECT epost FROM pamelding WHERE eventID = :eventID AND epost = :epost";
    
    $q = $pdo->prepare($sql2);
    $q->bindParam(':eventID', $id, PDO::PARAM_STR);
    $q->bindParam(':epost', $epost, PDO::PARAM_STR);

    $epost = $_SESSION['bruker']['navn'];

    try {
      $q->execute();
    } catch (PDOException $e) {
      //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
    }
    if($q->rowCount() > 0)
    {
      echo "<center><b>Du er allerede påmeldt!</b></center>";
    } else {
  
      //hvis du ikke er påmeldt, blir du lagt inn i databasen
    $query = "INSERT INTO pamelding (epost, pDato, eventID) VALUES (:epost, :pDato, :eventID)";
  
    //lager en prepared statement
    $q = $pdo->prepare($query);
  
    $q->bindParam(':epost', $epost, PDO::PARAM_STR);
    $q->bindParam(':pDato', $pDato, PDO::PARAM_STR);
    $q->bindParam(':eventID', $id, PDO::PARAM_STR);
  
    //legger input inn i variabler
    $pDato = date('Y-m-d H:i:s');
    
  
    try {
      $q->execute();
    } catch (PDOException $e) {
      //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
    }

    if ($pdo->lastInsertId() > 0) {
      echo "<center><b>Du er nå påmeldt.</b></center>";
    }

  }
  //hvis ikke session er aktiv, blir du sendt til loginsiden
  } else {
    header("Location: ./Login.php");
  }
}

include('../includes/Footer.inc.php');
?>