<?php
//avgjør hvilken header basert på om du er innlogget eller ikke
session_start();
if(isset($_SESSION['bruker']['innlogget']) !== true){
    include('../includes/Header.inc.php');
} else{
    include('../includes/Header.loggedin.inc.php');

}
include('../includes/manageEvent.inc.php');
include('../includes/db.inc.php');

//hvis manageEvent(knapp i manageEvent.inc.php) trykkes på
if (isset($_REQUEST['manageEvent'])) {
//query for å oppdatere eventtabellen
$sql = "UPDATE events 
        SET eventnavn = :eventnavn, eventtid = :eventtid, eventsted = :eventsted, katnavn = :katnavn 
        WHERE eventID = :id";

//lager en prepared statement
$q = $pdo->prepare($sql);
$q->bindParam(':id', $id, PDO::PARAM_STR);
$q->bindParam(':eventnavn', $eventnavn, PDO::PARAM_STR);
$q->bindParam(':eventtid', $eventtid, PDO::PARAM_STR);
$q->bindParam(':eventsted', $eventsted, PDO::PARAM_STR);
$q->bindParam(':katnavn', $katnavn, PDO::PARAM_STR);

//legger input inn i variabler
$id = $_REQUEST['id'];
$eventnavn = $_REQUEST['eventnavn'];
$eventtid = $_REQUEST['eventtid'];
$eventsted = $_REQUEST['eventsted'];
$katnavn = $_REQUEST['katnavn'];

//prøver å koble til databasen og kjøre query
try {
  $q->execute();
} catch (PDOException $e) {
  //echo "Error querying database: " . $e->getMessage() . "<br>"; // Never do this in production
}

//hvis en endring skjer
if ($q->rowCount() > 0) {
  
    echo "Eventet ble endret.";
    header("Location: ./myProfile.php");
} elseif ($q->rowCount() == 0) {

    echo "Ingen endringer ble gjort.";
} else {
   
    echo "Det skjedde en feil, vennligst prøv igjen.";
}
}

include('../includes/Footer.inc.php');

?>