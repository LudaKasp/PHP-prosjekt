<link rel="stylesheet" type="text/css" href="../css/Login.css">
<form action="Login.php" method="post">
    <div class="container">
    <label for="epost"><b>Epost</b></label>
    <input type="text" placeholder="Skriv Epost" name="epost" required>

    <label for="passord"><b>Passord</b></label>
    <input type="password" placeholder="Skriv passord" name="passord" required>

    <button type="submit" name="logginn">Logg inn</button>
    <span class="register"><a href="registrering.php">Opprett bruker</a></span>
  </div>
</form>