<?php 
error_reporting(0);
ini_set('display_errors', 0); 
?>

<link rel="stylesheet" type="text/css" href="../css/Registrering.css">
<form method="POST" action="../Klassebibliotek/manageEvent.php">
  <div class="container">
    <h1>Endre event</h1>
    <p>Vennligst fyll ut dette skjemaet for å endre ditt event.</p>
    <hr>
    <input type="hidden" name="id" value="<?php echo $_GET['id']; ?> ">
    <label for="eventnavn"><b>Navn for event</b></label>
    <input type="text" placeholder="Skriv eventnavnet" name="eventnavn" id="eventnavn" required>

    <label for="eventsted"><b>Adressen for eventet</b></label>
    <input type="text" placeholder="Skriv addressen" name="eventsted" id="eventsted" required>

    <label for="eventtid"><b>Tidspunktet for eventet</b></label>
    <br>
    <input type="datetime-local" placeholder="Dato for eventet" name="eventtid" id="eventtid" required>
    <br><br>

    <label for="katnavn"><b>Kategori for eventet</b></label>
    <br>
    <select required name="katnavn" > 
    <option value="" selected disabled hidden>Velg kategori...</option>
    <option value="Quiz">Quiz</option>
    <option value="Konsert">Konsert</option>
    <option value="Annet">Annet</option>
    </select> kategori<br><br>

    <button type="submit" name="manageEvent">Endre event</button>
  </div>