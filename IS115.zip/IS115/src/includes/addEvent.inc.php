<link rel="stylesheet" type="text/css" href="../css/Registrering.css">
<form action="addEvent.php" method="post" enctype="multipart/form-data">
  <div class="container">
    <h1>Legg til event</h1>
    <p>Vennligst fyll ut dette skjemaet for å opprette et event.</p>
    <hr>
    <label for="eventnavn"><b>Navn for event</b></label>
    <input type="text" placeholder="Skriv eventnavnet" name="eventnavn" id="eventnavn" required>

    <label for="eventsted"><b>Adressen for eventet</b></label>
    <input type="text" placeholder="Skriv addressen" name="eventsted" id="eventsted" required>

    <label for="eventtid"><b>Tidspunktet for eventet</b></label>
    <br>
    <input type="datetime-local" placeholder="Dato for eventet" name="eventtid" id="eventtid" required>
    <br><br>

    <label for="beskrivelse"><b>Kort beskrivelse av eventet</b></label>
    <br>
    <textarea name="beskrivelse" id="beskrivelse" maxlength="1000" required style="width:400px; height:200px;"> </textarea>
    <br><br>

    <label for="katnavn"><b>Kategori for eventet</b></label>
    <br>
    <select required name="katnavn" > 
    <option value="" selected disabled hidden>Velg kategori...</option>
    <option value="Quiz">Quiz</option>
    <option value="Konsert">Konsert</option>
    <option value="Annet">Annet</option>
    </select> kategori<br><br>

    <b>Last opp et bilde for ditt event:</b>
    <br>
    <input type="file" name="file">
    <br><br>
    <button type="submit" name="addEvent">Legg til event</button>
  </div>