<link rel="stylesheet" type="text/css" href="../css/Header.css">
<div class="header">
  <a href="index.php" class="logo">Eventhåndtering</a>
  <div class="header-right">
    <a href="index.php">Hjem</a>
    <a href="login.php">Login</a>
  </div>
</div>