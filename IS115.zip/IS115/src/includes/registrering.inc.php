<link rel="stylesheet" type="text/css" href="../css/Registrering.css">
<form action="registrering.php">
  <div class="container">
    <h1>Registrer</h1>
    <p>Vennligst fyll ut dette skjemaet for å opprette en bruker.</p>
    <hr>

    <label for="epost"><b>Email</b></label>
    <input type="text" placeholder="Skriv Epost" name="epost" id="epost" required>

    <label for="fnavn"><b>Fornavn</b></label>
    <input type="text" placeholder="Skriv fornavn" name="fnavn" id="fnavn" required>

    <label for="enavn"><b>Etternavn</b></label>
    <input type="text" placeholder="Skriv etternavn" name="enavn" id="enavn" required>

    <label for="tlf"><b>Telefonnummer</b></label>
    <input type="text" placeholder="Skriv nummeret" name="tlf" id="tlf" required>

    <label for="passord"><b>Passord</b></label>
    <input type="password" placeholder="Enter Password" name="passord" id="passord" required>

    <label for="psw-repeat"><b>Gjenta passord</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" id="psw-repeat" required>
    <hr>

    <button type="submit" name="registerbtn">Registrer</button>
  </div>

  <?php 
  
  function feilmelding() 
  {
    echo "<center>Passordene matcher ikke! Vennligst prøv på nytt.</center>";
  }
  
  ?>

  <div class="container signin">
    <p>Allerede bruker? <a href="Login.php">Login</a>.</p>
  </div>
</form>