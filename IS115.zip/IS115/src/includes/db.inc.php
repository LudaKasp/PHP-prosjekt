<?php
    
    //kode for connection til database
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', 'Monitor99');
    define('DB_NAME', 'eventproject');
    $dsn = 'mysql:dbname=' . DB_NAME . ';host=' . DB_HOST; // Driver is set here

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS);
    } catch (PDOException $e) {
        echo 'Error connecting to database: ' . $e->getMessage(); // Never do this in production
    }

    //kode for mysqli connection til database
    $db = mysqli_connect("localhost","root","Monitor99","eventproject");

    if(!$db)
    {
        die("Connection failed: " . mysqli_connect_error());
    }
?>