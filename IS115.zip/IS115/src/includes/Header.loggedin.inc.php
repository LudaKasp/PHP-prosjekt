<link rel="stylesheet" type="text/css" href="../css/Header.css">
<div class="header">
  <a href="index.php" class="logo">Eventhåndtering</a>
  <div class="header-right">
    <a href="index.php">Hjem</a>
    <a href="addEvent.php">Legg til event</a>
    <a href="myProfile.php">Min profil</a>
  </div>
</div>